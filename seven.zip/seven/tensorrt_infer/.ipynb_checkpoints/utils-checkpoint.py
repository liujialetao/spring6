import numpy as np
import tensorrt as trt
import common
import pycuda.autoinit
import pycuda.driver as cuda
import logging
logger = logging.getLogger(__name__)
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO
)


TRT_LOGGER = trt.Logger(trt.Logger.WARNING)
engine_model_path = "./model.trt"

class trt_engine():
    def __init__(self):
        # Build a TensorRT engine.
        self.engine = self.get_engine(engine_model_path)
        # Contexts are used to perform inference.
        self.context = self.engine.create_execution_context()

    def get_engine(self,engine_file_path):
        logger.info("Reading engine from file {}".format(engine_file_path))
        with open(engine_file_path, "rb") as f, trt.Runtime(TRT_LOGGER) as runtime:
            engine = runtime.deserialize_cuda_engine(f.read())
            return engine

    def engine_infer(self,feed_dict):
        #从engine中获取inputs, outputs, bindings, stream 的格式以及分配缓存
        self.context.active_optimization_profile = 0
        origin_inputshape = self.context.get_binding_shape(0)                # (1,-1)
        origin_inputshape[0],origin_inputshape[1] = feed_dict["input_ids"].shape     # (batch_size, max_sequence_length)
        self.context.set_binding_shape(0, (origin_inputshape))
        self.context.set_binding_shape(1, (origin_inputshape))
        self.context.set_binding_shape(2,(origin_inputshape))

        #输入数据填充
        inputs, outputs, bindings, stream = common.allocate_buffers_v2(self.engine, self.context)
        inputs[0].host = feed_dict["input_ids"]
        inputs[1].host = feed_dict["attention_mask"]
        inputs[2].host = feed_dict["token_type_ids"]

        #tensorrt推理
        trt_outputs = common.do_inference_v2(self.context, bindings=bindings, inputs=inputs, outputs=outputs, stream=stream)

        s_logits = np.reshape(trt_outputs[0],(-1,2))
        e_logits = np.reshape(trt_outputs[1], (-1, 2))
        return (s_logits,e_logits)


def span_decode(pred_output,raw_text, id2ent):
    start_logits = pred_output[0][1:-1]
    end_logits = pred_output[1][1:-1]

    predict = []
    start_pred = np.argmax(start_logits, -1)
    end_pred = np.argmax(end_logits, -1)

    for i, s_type in enumerate(start_pred):
        if s_type == 0:
            continue
        for j, e_type in enumerate(end_pred[i:]):
            if s_type == e_type:
                tmp_ent = raw_text[i:i + j + 1]
                predict.append((''.join(tmp_ent), i, i + j, s_type))
                break
    tmp = []
    for item in predict:
        if not tmp:
            tmp.append(item)
        else:
            if item[1] > tmp[-1][2]:
                tmp.append(item)
    res = []
    for ent, _, _, _ in tmp:
        res.append(ent)

    return res