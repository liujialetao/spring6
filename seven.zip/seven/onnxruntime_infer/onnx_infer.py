import torch
import onnxruntime
import sys
sys.path.append('../')
import logging
import time
import json
from info_extract.src.utils.options import Args
from info_extract.src.utils.model_utils import build_model
from transformers import BertTokenizer
import numpy as np
import warnings
warnings.filterwarnings("ignore")

logger = logging.getLogger(__name__)
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO
)


class Onnxruntime_Infer():
    def __init__(self,):
        self.init_ner_model()
        self.init_onnx()

    def init_ner_model(self,):
        logger.info("init ner model.........")
        opt = Args().get_parser()
        self.tokenizer = BertTokenizer.from_pretrained('../bert_model_data')
        with open('../info_extract/data/span_ent2id.json', encoding='utf-8') as f:
            self.ent2id = json.load(f)
            self.id2ent = {v: k for k, v in self.ent2id.items()}
        self.ner_model = build_model('span', opt.bert_dir, opt, num_tags=len(self.ent2id) + 1,
                                 dropout_prob=opt.dropout_prob,
                                 loss_type=opt.loss_type)
        self.ner_model.load_state_dict(torch.load("../info_extract/out/best_model.pt", map_location="cpu"), strict=True)
        self.ner_model.eval()

    def span_decode(self, pred_onnx,raw_text, id2ent):
        start_logits = pred_onnx[0][0][1:-1]
        end_logits = pred_onnx[1][0][1:-1]

        predict = []
        start_pred = np.argmax(start_logits, -1)
        end_pred = np.argmax(end_logits, -1)

        for i, s_type in enumerate(start_pred):
            if s_type == 0:
                continue
            for j, e_type in enumerate(end_pred[i:]):
                if s_type == e_type:
                    tmp_ent = raw_text[i:i + j + 1]
                    predict.append((''.join(tmp_ent), i, i + j, s_type))
                    break
        tmp = []
        for item in predict:
            if not tmp:
                tmp.append(item)
            else:
                if item[1] > tmp[-1][2]:
                    tmp.append(item)
        res = []
        for ent, _, _, _ in tmp:
            res.append(ent)

        return res


    def init_onnx(self,):
        logger.info("convert torch model to onnx model......")
        self.onnx_model_path = './model.onnx'
        operator_export_type = torch._C._onnx.OperatorExportTypes.ONNX
        onnx_input = self.make_onnx_infer_input()
        dynamic_axes = {'input_ids':[1],'attention_mask':[1],'token_type_ids':[1]}
        out = torch.onnx.export(
                                self.ner_model,
                                onnx_input,
                                self.onnx_model_path,
                                verbose = False,
                                operator_export_type = operator_export_type,
                                opset_version=10,
                                input_names = ['input_ids','attention_mask','token_type_ids'],
                                dynamic_axes = dynamic_axes
                            )
        providers=['TensorrtExecutionProvider', 'CUDAExecutionProvider', 'CPUExecutionProvider']
        providers=['CPUExecutionProvider']
        self.onnx_session = onnxruntime.InferenceSession(self.onnx_model_path,providers=providers)

    def make_onnx_infer_input(self,):
        onnx_input_ids = torch.LongTensor([[13,21,34,67]])
        onnx_token_type_ids = torch.LongTensor([[1,1,1,1]])
        onnx_input_mask = torch.LongTensor([[1,1,1,0]])
        return (onnx_input_ids,onnx_input_mask,onnx_token_type_ids)

    def onnx_infer(self,text):
        onnx_input = self.tokenizer.encode_plus(text=list(text),return_tensors='pt')
        pred_onnx = self.onnx_session.run(
            None,{
                'input_ids':onnx_input["input_ids"].numpy(),
                'token_type_ids': onnx_input["token_type_ids"].numpy(),
                'attention_mask': onnx_input["attention_mask"].numpy(),
            }
        )

        predict = self.span_decode(pred_onnx,text,self.id2ent)
        return predict



if __name__ == '__main__':
    onnx_f = Onnxruntime_Infer()
    demos = ["美亚光电护城河"]*10
    for text in demos:
        s = time.time()
        res = onnx_f.onnx_infer(text)
        e=time.time()
        print("{}\t{}\t{}".format(text,res[0],(e-s)*1000))
